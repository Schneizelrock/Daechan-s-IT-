<div id="footer-wrap">
	<p id="legal">(c) 2010 OurSite. Design by <a href="http://www.gmail.com">Book E-Commerce</a>.</p>
	</div>
