<div id="footer-wrap">
	<p id="legal">(c) 2018 OurSite. Design by <a href="http://www.gmail.com">Book E-Commerce System</a>.</p>
	</div>
