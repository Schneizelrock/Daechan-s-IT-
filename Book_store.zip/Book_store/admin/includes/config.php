<?php
$conn=mysqli_connect("localhost","root","1234","book_store")or die("Can't Connect...");

?>
